
function getCalc() {
    let width = document.getElementById("szelesseg").value;
    let height = document.getElementById("magassag").value;
    let paperType = document.getElementById("papirtipus").value;
    terulet = Math.round((width * height) / 10000);
    koltseg = terulet * paperType;
    console.log(terulet);
    console.log(koltseg);
    document.getElementById("koltseg").innerText = koltseg;
    document.getElementById("terulet").innerText = terulet;
    if (width && height < 50) {
        alert("Ellenőrizze az adatokat!")
    } else {
        document.getElementById("terulet").style.backgroundColor = "white";
        document.getElementById("terulet").style.fontWeight = "bold";
        document.getElementById("terulet").style.color = "green"
    }
    if (koltseg > 500) {
        document.getElementById("koltseg").style.backgroundColor = "white";
        document.getElementById("koltseg").style.fontWeight = "bold";
        document.getElementById("koltseg").style.color = "red";
    } else {
        document.getElementById("koltseg").style.backgroundColor = "white";
        document.getElementById("koltseg").style.fontWeight = "bold";
        document.getElementById("koltseg").style.color = "green"
    }
}